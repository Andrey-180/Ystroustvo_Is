﻿namespace GuessTheStandard
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblQuestionNumber = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.rbOption1 = new System.Windows.Forms.RadioButton();
            this.rbOption2 = new System.Windows.Forms.RadioButton();
            this.rbOption3 = new System.Windows.Forms.RadioButton();
            this.rbOption4 = new System.Windows.Forms.RadioButton();
            this.btnNext = new System.Windows.Forms.Button();
            this.lblProgress = new System.Windows.Forms.Label();
            this.groupBoxOptions = new System.Windows.Forms.GroupBox();
            this.groupBoxOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblQuestionNumber
            // 
            this.lblQuestionNumber.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblQuestionNumber.Location = new System.Drawing.Point(12, 20);
            this.lblQuestionNumber.Size = new System.Drawing.Size(460, 25);
            this.lblQuestionNumber.Text = "Вопрос 1 из 5";
            this.lblQuestionNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDescription
            // 
            this.lblDescription.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblDescription.Location = new System.Drawing.Point(12, 50);
            this.lblDescription.Size = new System.Drawing.Size(460, 60);
            this.lblDescription.Text = "Текст вопроса";
            this.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBoxOptions
            // 
            this.groupBoxOptions.Controls.Add(this.rbOption1);
            this.groupBoxOptions.Controls.Add(this.rbOption2);
            this.groupBoxOptions.Controls.Add(this.rbOption3);
            this.groupBoxOptions.Controls.Add(this.rbOption4);
            this.groupBoxOptions.Location = new System.Drawing.Point(50, 120);
            this.groupBoxOptions.Size = new System.Drawing.Size(380, 150);
            this.groupBoxOptions.Text = "Выберите правильный стандарт:";
            // 
            // rbOption1
            this.rbOption1.Location = new System.Drawing.Point(20, 30);
            this.rbOption1.Size = new System.Drawing.Size(340, 24);
            // 
            // rbOption2
            // 
            this.rbOption2.Location = new System.Drawing.Point(20, 60);
            this.rbOption2.Size = new System.Drawing.Size(340, 24);
            // 
            // rbOption3
            // 
            this.rbOption3.Location = new System.Drawing.Point(20, 90);
            this.rbOption3.Size = new System.Drawing.Size(340, 24);
            // 
            // rbOption4
            // 
            this.rbOption4.Location = new System.Drawing.Point(20, 120);
            this.rbOption4.Size = new System.Drawing.Size(340, 24);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(180, 290);
            this.btnNext.Size = new System.Drawing.Size(120, 35);
            this.btnNext.Text = "Далее";
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblProgress
            // 
            this.lblProgress.Location = new System.Drawing.Point(12, 340);
            this.lblProgress.Size = new System.Drawing.Size(460, 20);
            this.lblProgress.Text = "Правильных ответов: 0 из 5";
            this.lblProgress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(484, 381);
            this.Controls.Add(this.lblProgress);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.groupBoxOptions);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblQuestionNumber);
            this.Name = "Form1";
            this.Text = "Угадай стандарт";
            this.groupBoxOptions.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label lblQuestionNumber;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.RadioButton rbOption1;
        private System.Windows.Forms.RadioButton rbOption2;
        private System.Windows.Forms.RadioButton rbOption3;
        private System.Windows.Forms.RadioButton rbOption4;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label lblProgress;
        private System.Windows.Forms.GroupBox groupBoxOptions;
    }
}