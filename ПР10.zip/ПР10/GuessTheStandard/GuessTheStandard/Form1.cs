﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuessTheStandard
{
    public partial class Form1 : Form
    {
        private List<Question> questions;
        private int currentQuestionIndex = 0;
        private int correctAnswersCount = 0;

        public Form1()
        {
            InitializeComponent();
            InitializeQuestions();
            LoadQuestion();
        }

        private void InitializeQuestions()
        {
            questions = new List<Question>
            {
                new Question(
                    "Какой стандарт определяет формат чисел с плавающей точкой?",
                    new List<string> { "ISO 9001", "IEEE 802.11", "ASCII", "IEEE 754" },
                    "IEEE 754"),
                new Question(
                    "Какой стандарт описывает базовый набор символов?",
                    new List<string> { "Unicode", "ASCII", "UTF-8", "ISO 8859-1" },
                    "ASCII"),
                new Question(
                    "Какой стандарт определяет требования к системе менеджмента качества?",
                    new List<string> { "ISO 9001", "IEEE 802.11", "GMP", "HACCP" },
                    "ISO 9001"),
                new Question(
                    "Какой стандарт описывает протоколы для Wi-Fi?",
                    new List<string> { "IEEE 802.3", "IEEE 802.11", "IEEE 1394", "Bluetooth" },
                    "IEEE 802.11"),
                new Question(
                    "Какой стандарт кодировки включает символы всех письменностей мира?",
                    new List<string> { "ASCII", "KOI-8", "Unicode", "Windows-1251" },
                    "Unicode")
            };
        }

        private void LoadQuestion()
        {
            if (currentQuestionIndex < questions.Count)
            {
                var q = questions[currentQuestionIndex];
                lblQuestionNumber.Text = $"Вопрос {currentQuestionIndex + 1} из {questions.Count}";
                lblDescription.Text = q.Description;

                rbOption1.Text = q.Options[0];
                rbOption2.Text = q.Options[1];
                rbOption3.Text = q.Options[2];
                rbOption4.Text = q.Options[3];

                // Сброс выбора
                rbOption1.Checked = rbOption2.Checked = rbOption3.Checked = rbOption4.Checked = false;
                lblProgress.Text = $"Правильных ответов: {correctAnswersCount} из {questions.Count}";
            }
            else
            {
                ShowResults();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            RadioButton selected = GetSelectedRadioButton();
            if (selected == null)
            {
                MessageBox.Show("Пожалуйста, выберите вариант ответа!");
                return;
            }

            if (selected.Text == questions[currentQuestionIndex].CorrectAnswer)
            {
                correctAnswersCount++;
            }

            currentQuestionIndex++;
            LoadQuestion();
        }

        private RadioButton GetSelectedRadioButton()
        {
            if (rbOption1.Checked) return rbOption1;
            if (rbOption2.Checked) return rbOption2;
            if (rbOption3.Checked) return rbOption3;
            if (rbOption4.Checked) return rbOption4;
            return null;
        }

        private void ShowResults()
        {
            double percent = (double)correctAnswersCount / questions.Count * 100;
            string message = $"Тест завершен!\nПравильных ответов: {correctAnswersCount} из {questions.Count}\nПроцент: {percent:F1}%\n\nХотите пройти тест заново?";

            DialogResult result = MessageBox.Show(message, "Результат теста", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (result == DialogResult.Yes)
            {
                currentQuestionIndex = 0;
                correctAnswersCount = 0;
                LoadQuestion();
            }
            else
            {
                Application.Exit();
            }
        }
    }

    public class Question
    {
        public string Description { get; set; }
        public List<string> Options { get; set; }
        public string CorrectAnswer { get; set; }

        public Question(string description, List<string> options, string correctAnswer)
        {
            Description = description;
            Options = options;
            CorrectAnswer = correctAnswer;
        }
    }
}
