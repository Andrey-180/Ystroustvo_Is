﻿namespace PhysicsApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.groupBoxInput = new System.Windows.Forms.GroupBox();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtV0 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBoxResults = new System.Windows.Forms.GroupBox();
            this.lblFinalV = new System.Windows.Forms.Label();
            this.lblPath = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.chartMotion = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lblEquation = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.groupBoxInput.SuspendLayout();
            this.groupBoxResults.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartMotion)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxInput
            // 
            this.groupBoxInput.Controls.Add(this.btnCalculate);
            this.groupBoxInput.Controls.Add(this.btnClear);
            this.groupBoxInput.Controls.Add(this.txtTime);
            this.groupBoxInput.Controls.Add(this.txtA);
            this.groupBoxInput.Controls.Add(this.txtV0);
            this.groupBoxInput.Controls.Add(this.label3);
            this.groupBoxInput.Controls.Add(this.label2);
            this.groupBoxInput.Controls.Add(this.label1);
            this.groupBoxInput.Location = new System.Drawing.Point(12, 12);
            this.groupBoxInput.Size = new System.Drawing.Size(260, 160);
            this.groupBoxInput.Text = "Входные данные";
            // 
            // label1, label2, label3
            this.label1.Location = new System.Drawing.Point(10, 30);
            this.label1.Text = "Нач. скорость (м/с):";
            this.label1.Size = new System.Drawing.Size(120, 20);
            this.label2.Location = new System.Drawing.Point(10, 60);
            this.label2.Text = "Ускорение (м/с²):";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label3.Location = new System.Drawing.Point(10, 90);
            this.label3.Text = "Время (t), с:";
            this.label3.Size = new System.Drawing.Size(120, 20);
            // 
            // txtV0, txtA, txtTime
            this.txtV0.Location = new System.Drawing.Point(145, 27);
            this.txtV0.Size = new System.Drawing.Size(100, 20);
            this.txtA.Location = new System.Drawing.Point(145, 57);
            this.txtA.Size = new System.Drawing.Size(100, 20);
            this.txtTime.Location = new System.Drawing.Point(145, 87);
            this.txtTime.Size = new System.Drawing.Size(100, 20);
            // 
            // Кнопки
            this.btnCalculate.Location = new System.Drawing.Point(10, 120);
            this.btnCalculate.Size = new System.Drawing.Size(110, 30);
            this.btnCalculate.Text = "Рассчитать";
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            this.btnClear.Location = new System.Drawing.Point(135, 120);
            this.btnClear.Size = new System.Drawing.Size(110, 30);
            this.btnClear.Text = "Очистить";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Результаты
            this.groupBoxResults.Controls.Add(this.lblFinalV);
            this.groupBoxResults.Controls.Add(this.lblPath);
            this.groupBoxResults.Controls.Add(this.lblType);
            this.groupBoxResults.Location = new System.Drawing.Point(12, 180);
            this.groupBoxResults.Size = new System.Drawing.Size(260, 100);
            this.groupBoxResults.Text = "Результаты";
            this.lblType.Location = new System.Drawing.Point(10, 25);
            this.lblType.AutoSize = true;
            this.lblPath.Location = new System.Drawing.Point(10, 50);
            this.lblPath.AutoSize = true;
            this.lblFinalV.Location = new System.Drawing.Point(10, 75);
            this.lblFinalV.AutoSize = true;
            // 
            // chartMotion
            // 
            chartArea1.Name = "ChartArea1";
            chartArea1.AxisX.Title = "Время, с";
            chartArea1.AxisY.Title = "Путь, м";
            this.chartMotion.ChartAreas.Add(chartArea1);
            this.chartMotion.Location = new System.Drawing.Point(290, 12);
            this.chartMotion.Size = new System.Drawing.Size(550, 300);
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.BorderWidth = 3;
            series1.Name = "PathSeries";
            this.chartMotion.Series.Add(series1);
            // 
            // lblEquation, lblDescription
            this.lblEquation.Location = new System.Drawing.Point(290, 320);
            this.lblEquation.Size = new System.Drawing.Size(550, 20);
            this.lblDescription.Location = new System.Drawing.Point(12, 290);
            this.lblDescription.Size = new System.Drawing.Size(260, 60);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(860, 360);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblEquation);
            this.Controls.Add(this.chartMotion);
            this.Controls.Add(this.groupBoxResults);
            this.Controls.Add(this.groupBoxInput);
            this.Name = "Form1";
            this.Text = "Анализатор механического движения";
            this.groupBoxInput.ResumeLayout(false);
            this.groupBoxInput.PerformLayout();
            this.groupBoxResults.ResumeLayout(false);
            this.groupBoxResults.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartMotion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.GroupBox groupBoxInput;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtV0;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBoxResults;
        private System.Windows.Forms.Label lblFinalV;
        private System.Windows.Forms.Label lblPath;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMotion;
        private System.Windows.Forms.Label lblEquation;
        private System.Windows.Forms.Label lblDescription;
    }
}