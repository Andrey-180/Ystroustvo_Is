﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhysicsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double v0 = double.Parse(txtV0.Text);
                double a = double.Parse(txtA.Text);
                double t = double.Parse(txtTime.Text);

                if (t < 0) { MessageBox.Show("Время не может быть отрицательным!"); return; }
                if (t == 0) { MessageBox.Show("Время равно 0. График не построить."); return; }

                double path = v0 * t + (a * t * t) / 2;
                double vEnd = v0 + a * t;

                string type, desc, sign = a >= 0 ? "+" : "-";

                if (a == 0) { type = "Равномерное"; desc = "Скорость постоянна."; }
                else if (a > 0) { type = "Равноускоренное"; desc = "Разгон."; }
                else { type = "Равнозамедленное"; desc = "Торможение."; }

                lblType.Text = $"Тип: {type}";
                lblPath.Text = $"Путь: {path:F2} м";
                lblFinalV.Text = $"Кон. скорость: {vEnd:F2} м/с";
                lblDescription.Text = desc;
                lblEquation.Text = $"Уравнение: S(t) = {v0}t {sign} ({Math.Abs(a)}t²)/2";

                chartMotion.Series["PathSeries"].Points.Clear();
                for (int i = 0; i <= 20; i++)
                {
                    double curT = (t / 20) * i;
                    double curS = v0 * curT + (a * curT * curT) / 2;
                    chartMotion.Series["PathSeries"].Points.AddXY(curT, curS);
                }
            }
            catch { MessageBox.Show("Ошибка! Введите числа через запятую."); }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtV0.Text = "0"; txtA.Text = "0"; txtTime.Text = "0";
            lblType.Text = "Тип: ---"; lblPath.Text = "Путь: ---";
            lblFinalV.Text = "Кон. скорость: ---"; lblDescription.Text = "Описание...";
            lblEquation.Text = "Уравнение: S(t) = ...";
            chartMotion.Series["PathSeries"].Points.Clear();
        }
    }
}