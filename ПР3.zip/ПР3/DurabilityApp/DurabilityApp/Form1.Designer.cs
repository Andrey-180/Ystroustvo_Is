﻿namespace DurabilityApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtMt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtVx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtT = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.rtbOutput = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(20, 20);
            this.label1.Text = "Средняя наработка (Mt, ч):";
            this.label1.Size = new System.Drawing.Size(180, 20);
            // 
            // txtMt
            // 
            this.txtMt.Location = new System.Drawing.Point(210, 17);
            this.txtMt.Text = "1500";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(20, 50);
            this.label2.Text = "Коэф. вариации (vx):";
            this.label2.Size = new System.Drawing.Size(180, 20);
            // 
            // txtVx
            // 
            this.txtVx.Location = new System.Drawing.Point(210, 47);
            this.txtVx.Text = "0,3";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(20, 80);
            this.label3.Text = "Наработка (t, ч):";
            this.label3.Size = new System.Drawing.Size(180, 20);
            // 
            // txtT
            // 
            this.txtT.Location = new System.Drawing.Point(210, 77);
            this.txtT.Text = "1000";
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(20, 115);
            this.btnCalc.Size = new System.Drawing.Size(290, 35);
            this.btnCalc.Text = "Рассчитать";
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // rtbOutput
            // 
            this.rtbOutput.Location = new System.Drawing.Point(20, 160);
            this.rtbOutput.Size = new System.Drawing.Size(400, 300);
            this.rtbOutput.ReadOnly = true;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(450, 480);
            this.Controls.Add(this.rtbOutput);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtT);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtVx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMt);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Расчет показателей долговечности";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtVx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtT;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.RichTextBox rtbOutput;
    }
}