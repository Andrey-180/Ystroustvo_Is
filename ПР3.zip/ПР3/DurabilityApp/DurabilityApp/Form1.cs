﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DurabilityApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                double Mt = double.Parse(txtMt.Text);
                double vx = double.Parse(txtVx.Text);
                double t = double.Parse(txtT.Text);

                // 1. СКО
                double sigma = vx * Mt;

                // 2. Квантиль Up
                double Up = (t - Mt) / sigma;

                // 3. Функция Лапласа (аппроксимация)
                double Phi = GetLaplace(Up);

                // 4. Вероятности
                double Q = Phi;
                double P = 1 - Q;

                rtbOutput.Clear();
                rtbOutput.AppendText("РАСЧЕТ ПОКАЗАТЕЛЕЙ НАДЕЖНОСТИ\n\n");
                rtbOutput.AppendText($"ИСХОДНЫЕ ДАННЫЕ:\n");
                rtbOutput.AppendText($"• Средняя наработка: Mt = {Mt} ч.\n");
                rtbOutput.AppendText($"• Коэф. вариации: vx = {vx}\n");
                rtbOutput.AppendText($"• Наработка для расчета: t = {t} ч.\n\n");

                rtbOutput.AppendText("РАСЧЕТНЫЕ ПОКАЗАТЕЛИ:\n");
                rtbOutput.AppendText($"1. Среднее квадратическое отклонение:\n");
                rtbOutput.AppendText($"   σt = vx * Mt = {vx} * {Mt} = {sigma} час\n\n");

                rtbOutput.AppendText($"2. Квантиль нормального распределения:\n");
                rtbOutput.AppendText($"   Up = (t - Mt) / σt = ({t} - {Mt}) / {sigma} = {Up:F4}\n\n");

                rtbOutput.AppendText($"3. Функция Лапласа:\n");
                rtbOutput.AppendText($"   Φ(Up) = Φ({Up:F2}) = {Phi:F4}\n\n");

                rtbOutput.AppendText($"4. ВЕРОЯТНОСТЬ ОТКАЗА:\n");
                rtbOutput.AppendText($"   Q(t) = Φ(Up) = {Q:F4} или {(Q * 100):F2}%\n\n");

                rtbOutput.AppendText($"5. ВЕРОЯТНОСТЬ БЕЗОТКАЗНОЙ РАБОТЫ:\n");
                rtbOutput.AppendText($"   P(t) = 1 - Q(t) = {P:F4} или {(P * 100):F2}%");

                MessageBox.Show($"Расчет окончен!\nP(t) = {P:F4}", "Результат", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка! Проверьте ввод данных (через запятую).");
            }
        }

        // Математическая аппроксимация функции Лапласа (CDF)
        private double GetLaplace(double x)
        {
            double a1 = 0.254829592;
            double a2 = -0.284496736;
            double a3 = 1.421413741;
            double a4 = -1.453152027;
            double a5 = 1.061405429;
            double p = 0.3275911;

            int sign = (x < 0) ? -1 : 1;
            x = Math.Abs(x) / Math.Sqrt(2.0);

            double t = 1.0 / (1.0 + p * x);
            double y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.Exp(-x * x);

            return 0.5 * (1.0 + sign * y);
        }
    }
}
