﻿namespace ReliabilityComplex
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblT = new System.Windows.Forms.Label();
            this.txtT = new System.Windows.Forms.TextBox();
            this.lblTb = new System.Windows.Forms.Label();
            this.txtTb = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.rtbResults = new System.Windows.Forms.RichTextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Text = "Расчет комплексных показателей надежности (Вариант 4)";
            // 
            // lblT
            // 
            this.lblT.Location = new System.Drawing.Point(15, 50);
            this.lblT.Text = "Наработка на отказ (T), ч:";
            this.lblT.Size = new System.Drawing.Size(180, 20);
            // 
            // txtT
            // 
            this.txtT.Location = new System.Drawing.Point(200, 47);
            this.txtT.Text = "500"; // Значение для 4 варианта
            // 
            // lblTb
            // 
            this.lblTb.Location = new System.Drawing.Point(15, 80);
            this.lblTb.Text = "Время восстановления (Tb), ч:";
            this.lblTb.Size = new System.Drawing.Size(180, 20);
            // 
            // txtTb
            // 
            this.txtTb.Location = new System.Drawing.Point(200, 77);
            this.txtTb.Text = "5"; // Значение для 4 варианта
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(15, 120);
            this.btnCalculate.Size = new System.Drawing.Size(285, 35);
            this.btnCalculate.Text = "Рассчитать показатели";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // rtbResults
            // 
            this.rtbResults.Location = new System.Drawing.Point(15, 170);
            this.rtbResults.Size = new System.Drawing.Size(450, 250);
            this.rtbResults.Text = "";
            this.rtbResults.ReadOnly = true;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(484, 441);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.rtbResults);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtTb);
            this.Controls.Add(this.lblTb);
            this.Controls.Add(this.txtT);
            this.Controls.Add(this.lblT);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Определение комплексных показателей надежности";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblT;
        private System.Windows.Forms.TextBox txtT;
        private System.Windows.Forms.Label lblTb;
        private System.Windows.Forms.TextBox txtTb;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.RichTextBox rtbResults;
        private System.Windows.Forms.Label lblTitle;
    }
}