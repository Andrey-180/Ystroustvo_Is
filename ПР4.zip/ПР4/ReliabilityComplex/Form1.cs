﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReliabilityComplex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double T = double.Parse(txtT.Text);   
                double Tb = double.Parse(txtTb.Text); 

                
                double lambda = 1.0 / T;

       
                double mu = 1.0 / Tb;


                double Kr = T / (T + Tb);


                double Kp = 1.0 - Kr;

             
                rtbResults.Clear();
                rtbResults.AppendText("РЕЗУЛЬТАТЫ РАСЧЕТА (Вариант 4):\n\n");
                rtbResults.AppendText($"1. Интенсивность отказов (λ = 1/T):\n");
                rtbResults.AppendText($"   λ = 1 / {T} = {lambda:F6} 1/ч\n\n");

                rtbResults.AppendText($"2. Интенсивность восстановления (μ = 1/Tb):\n");
                rtbResults.AppendText($"   μ = 1 / {Tb} = {mu:F4} 1/ч\n\n");

                rtbResults.AppendText($"3. Коэффициент готовности (Кг = T / (T + Tb)):\n");
                rtbResults.AppendText($"   Кг = {T} / ({T} + {Tb}) = {Kr:F4} ({Kr * 100:F2}%)\n\n");

                rtbResults.AppendText($"4. Коэффициент простоя (Кп = Tb / (T + Tb)):\n");
                rtbResults.AppendText($"   Кп = {Tb} / ({T} + {Tb}) = {Kp:F4} ({Kp * 100:F2}%)\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка ввода: " + ex.Message);
            }
        }
    }
}
