﻿namespace NetworkTerminalSim
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlNetwork = new System.Windows.Forms.Panel();
            this.txtConsole = new System.Windows.Forms.RichTextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.numPacketsPerSec = new System.Windows.Forms.NumericUpDown();
            this.lblPackets = new System.Windows.Forms.Label();
            this.tmrSpawn = new System.Windows.Forms.Timer(this.components);
            this.tmrAnimate = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.numPacketsPerSec)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlNetwork
            // 
            this.pnlNetwork.BackColor = System.Drawing.Color.White;
            this.pnlNetwork.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlNetwork.Location = new System.Drawing.Point(12, 12);
            this.pnlNetwork.Name = "pnlNetwork";
            this.pnlNetwork.Size = new System.Drawing.Size(760, 250);
            this.pnlNetwork.TabIndex = 0;
            this.pnlNetwork.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlNetwork_Paint);
            // 
            // txtConsole
            // 
            this.txtConsole.BackColor = System.Drawing.Color.Black;
            this.txtConsole.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtConsole.ForeColor = System.Drawing.Color.Lime;
            this.txtConsole.Location = new System.Drawing.Point(12, 268);
            this.txtConsole.Name = "txtConsole";
            this.txtConsole.ReadOnly = true;
            this.txtConsole.Size = new System.Drawing.Size(760, 140);
            this.txtConsole.TabIndex = 1;
            this.txtConsole.Text = "";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(12, 415);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(100, 30);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Старт";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(118, 415);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(100, 30);
            this.btnStop.TabIndex = 3;
            this.btnStop.Text = "Стоп";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(672, 415);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 30);
            this.btnClear.TabIndex = 4;
            this.btnClear.Text = "Очистить";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // numPacketsPerSec
            // 
            this.numPacketsPerSec.Location = new System.Drawing.Point(359, 421);
            this.numPacketsPerSec.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numPacketsPerSec.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numPacketsPerSec.Name = "numPacketsPerSec";
            this.numPacketsPerSec.Size = new System.Drawing.Size(60, 20);
            this.numPacketsPerSec.TabIndex = 1;
            this.numPacketsPerSec.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numPacketsPerSec.ValueChanged += new System.EventHandler(this.numPacketsPerSec_ValueChanged);
            // 
            // lblPackets
            // 
            this.lblPackets.AutoSize = true;
            this.lblPackets.Location = new System.Drawing.Point(240, 423);
            this.lblPackets.Name = "lblPackets";
            this.lblPackets.Size = new System.Drawing.Size(113, 13);
            this.lblPackets.TabIndex = 0;
            this.lblPackets.Text = "Пакетов в сек (1-10):";
            // 
            // tmrSpawn
            // 
            this.tmrSpawn.Tick += new System.EventHandler(this.tmrSpawn_Tick);
            // 
            // tmrAnimate
            // 
            this.tmrAnimate.Interval = 30;
            this.tmrAnimate.Tick += new System.EventHandler(this.tmrAnimate_Tick);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(784, 451);
            this.Controls.Add(this.lblPackets);
            this.Controls.Add(this.numPacketsPerSec);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.txtConsole);
            this.Controls.Add(this.pnlNetwork);
            this.Name = "Form1";
            this.Text = "Сетевой терминал - Симуляция ЛВС";
            ((System.ComponentModel.ISupportInitialize)(this.numPacketsPerSec)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Panel pnlNetwork;
        private System.Windows.Forms.RichTextBox txtConsole;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.NumericUpDown numPacketsPerSec;
        private System.Windows.Forms.Label lblPackets;
        private System.Windows.Forms.Timer tmrSpawn;
        private System.Windows.Forms.Timer tmrAnimate;
    }
}