﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;


namespace NetworkTerminalSim
{
    public partial class Form1 : Form
    {
        private List<Packet> packets = new List<Packet>();
        private Random rnd = new Random();
        private int packetCounter = 0;
        private Point swPos;
        private Point[] pcPos = new Point[4];
        private string[] pcNames = { "ПК1", "ПК2", "ПК3", "ПК4" };
        private Color[] packetColors = { Color.Red, Color.Blue, Color.Green, Color.Orange, Color.Purple, Color.Cyan };

        public Form1()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            typeof(Panel).GetProperty("DoubleBuffered", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).SetValue(pnlNetwork, true, null);
            InitializeNetworkPositions();
        }

        private void InitializeNetworkPositions()
        {
            swPos = new Point(pnlNetwork.Width / 2, pnlNetwork.Height / 2);
            pcPos[0] = new Point(50, 50);
            pcPos[1] = new Point(pnlNetwork.Width - 50, 50);
            pcPos[2] = new Point(50, pnlNetwork.Height - 50);
            pcPos[3] = new Point(pnlNetwork.Width - 50, pnlNetwork.Height - 50);
        }

        private void Log(string message)
        {
            if (txtConsole.InvokeRequired)
            {
                txtConsole.Invoke(new Action<string>(Log), message);
                return;
            }
            txtConsole.AppendText($"[{DateTime.Now:HH:mm:ss.fff}] {message}{Environment.NewLine}");
            txtConsole.SelectionStart = txtConsole.Text.Length;
            txtConsole.ScrollToCaret();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrSpawn.Interval = 1000 / (int)numPacketsPerSec.Value;
            tmrSpawn.Start();
            tmrAnimate.Start();
            Log("Симуляция сети запущена...");
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            tmrSpawn.Stop();
            tmrAnimate.Stop();
            Log($"Передача пакетов остановлена. Всего передано: {packetCounter}");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtConsole.Clear();
            packets.Clear();
            packetCounter = 0;
            pnlNetwork.Invalidate();
        }

        private void numPacketsPerSec_ValueChanged(object sender, EventArgs e)
        {
            tmrSpawn.Interval = 1000 / (int)numPacketsPerSec.Value;
        }

        private void tmrSpawn_Tick(object sender, EventArgs e)
        {
            int src = rnd.Next(4);
            int dest;
            do { dest = rnd.Next(4); } while (dest == src);

            packetCounter++;
            var packet = new Packet
            {
                ID = packetCounter,
                SourceIdx = src,
                DestIdx = dest,
                Color = packetColors[rnd.Next(packetColors.Length)],
                Size = rnd.Next(64, 1501),
                Progress = 0,
                IsToSwitch = true,
                StartTime = DateTime.Now
            };

            packets.Add(packet);
            Log($"Пакет #{packet.ID}: {pcNames[src]} -> {pcNames[dest]}, Размер: {packet.Size} байт");
        }

        private void tmrAnimate_Tick(object sender, EventArgs e)
        {
            for (int i = packets.Count - 1; i >= 0; i--)
            {
                var p = packets[i];
                p.Progress += 0.05f;

                if (p.Progress >= 1.0f)
                {
                    if (p.IsToSwitch)
                    {
                        p.IsToSwitch = false;
                        p.Progress = 0;
                        Log($"Пакет #{p.ID} достиг SWITCH");
                    }
                    else
                    {
                        var delay = (DateTime.Now - p.StartTime).TotalMilliseconds;
                        Log($"Пакет #{p.ID} доставлен на {pcNames[p.DestIdx]} (задержка: {(int)delay} мс)");
                        packets.RemoveAt(i);
                    }
                }
            }
            pnlNetwork.Invalidate();
        }

        private void pnlNetwork_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Pen linePen = new Pen(Color.Gray, 1) { DashStyle = DashStyle.Dash };
            foreach (var pos in pcPos)
            {
                g.DrawLine(linePen, pos, swPos);
            }

            Rectangle swRect = new Rectangle(swPos.X - 25, swPos.Y - 20, 50, 40);
            g.FillRectangle(Brushes.LightSkyBlue, swRect);
            g.DrawRectangle(Pens.Blue, swRect);
            g.DrawString("SWITCH", this.Font, Brushes.Black, swPos.X - 22, swPos.Y - 8);

            for (int i = 0; i < 4; i++)
            {
                Rectangle pcRect = new Rectangle(pcPos[i].X - 20, pcPos[i].Y - 15, 40, 30);
                g.FillRectangle(Brushes.LightGray, pcRect);
                g.DrawRectangle(Pens.Black, pcRect);
                g.DrawString(pcNames[i], this.Font, Brushes.Black, pcPos[i].X - 15, pcPos[i].Y - 5);
            }

            foreach (var p in packets)
            {
                Point start = p.IsToSwitch ? pcPos[p.SourceIdx] : swPos;
                Point end = p.IsToSwitch ? swPos : pcPos[p.DestIdx];

                int curX = (int)(start.X + (end.X - start.X) * p.Progress);
                int curY = (int)(start.Y + (end.Y - start.Y) * p.Progress);

                g.FillEllipse(new SolidBrush(p.Color), curX - 6, curY - 6, 12, 12);
                g.DrawEllipse(Pens.Black, curX - 6, curY - 6, 12, 12);
                g.DrawString(p.ID.ToString(), new Font("Arial", 7), Brushes.White, curX - 5, curY - 5);
            }
        }
    }

    public class Packet
    {
        public int ID { get; set; }
        public int SourceIdx { get; set; }
        public int DestIdx { get; set; }
        public Color Color { get; set; }
        public int Size { get; set; }
        public float Progress { get; set; }
        public bool IsToSwitch { get; set; }
        public DateTime StartTime { get; set; }
    }
}
