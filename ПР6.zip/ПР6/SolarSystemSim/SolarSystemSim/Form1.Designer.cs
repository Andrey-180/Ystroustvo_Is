﻿namespace SolarSystemSim
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timerUpdate = new System.Windows.Forms.Timer(this.components);
            this.btnPause = new System.Windows.Forms.Button();
            this.btnFaster = new System.Windows.Forms.Button();
            this.btnSlower = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // timerUpdate
            // 
            this.timerUpdate.Enabled = true;
            this.timerUpdate.Interval = 20;
            this.timerUpdate.Tick += new System.EventHandler(this.timerUpdate_Tick);
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(12, 12);
            this.btnPause.Size = new System.Drawing.Size(75, 23);
            this.btnPause.Text = "Пауза";
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // btnFaster
            // 
            this.btnFaster.Location = new System.Drawing.Point(93, 12);
            this.btnFaster.Size = new System.Drawing.Size(75, 23);
            this.btnFaster.Text = "Быстрее";
            this.btnFaster.Click += new System.EventHandler(this.btnFaster_Click);
            // 
            // btnSlower
            // 
            this.btnSlower.Location = new System.Drawing.Point(174, 12);
            this.btnSlower.Size = new System.Drawing.Size(75, 23);
            this.btnSlower.Text = "Медленнее";
            this.btnSlower.Click += new System.EventHandler(this.btnSlower_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.btnSlower);
            this.Controls.Add(this.btnFaster);
            this.Controls.Add(this.btnPause);
            this.Name = "Form1";
            this.Text = "Солнечная система - Достоверность ИС";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Timer timerUpdate;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnFaster;
        private System.Windows.Forms.Button btnSlower;
    }
}