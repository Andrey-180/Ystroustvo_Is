﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace SolarSystemSim
{
    public partial class Form1 : Form
    {
        private List<Planet> planets;
        private float zoom = 1.0f;
        private float speedMultiplier = 1.0f;
        private bool isPaused = false;
        private int centerX, centerY;

        public Form1()
        {
            InitializeComponent();
            InitializeSolarSystem();
            this.MouseWheel += Form1_MouseWheel;
        }

        private void InitializeSolarSystem()
        {
            planets = new List<Planet>
            {
                new Planet("Меркурий", 40, 0.047f, 6, Color.Gray, 0),
                new Planet("Венера", 70, 0.035f, 10, Color.Orange, 45),
                new Planet("Земля", 100, 0.029f, 11, Color.RoyalBlue, 90),
                new Planet("Марс", 130, 0.024f, 8, Color.Red, 135),
                new Planet("Юпитер", 180, 0.013f, 22, Color.SandyBrown, 180),
                new Planet("Сатурн", 230, 0.009f, 18, Color.Khaki, 225),
                new Planet("Уран", 270, 0.006f, 14, Color.LightCyan, 270),
                new Planet("Нептун", 310, 0.005f, 14, Color.Blue, 315)
            };
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.Black);

            centerX = this.ClientSize.Width / 2;
            centerY = this.ClientSize.Height / 2;

            float sunSize = 40 * zoom;
            g.FillEllipse(Brushes.Yellow, centerX - sunSize / 2, centerY - sunSize / 2, sunSize, sunSize);

            foreach (var planet in planets)
            {
                float orbitRad = planet.OrbitRadius * 2 * zoom;
                g.DrawEllipse(Pens.DimGray, centerX - orbitRad, centerY - orbitRad, orbitRad * 2, orbitRad * 2);

                double rad = planet.Angle * Math.PI / 180;
                float x = centerX + (float)Math.Cos(rad) * orbitRad;
                float y = centerY + (float)Math.Sin(rad) * orbitRad;

                float pSize = planet.Size * zoom;
                if (pSize < 4) pSize = 4;
                if (pSize > 40) pSize = 40;

                using (Brush b = new SolidBrush(planet.Color))
                {
                    g.FillEllipse(b, x - pSize / 2, y - pSize / 2, pSize, pSize);
                }
                g.DrawString(planet.Name, this.Font, Brushes.White, x + pSize / 2, y);
            }
        }

        private void timerUpdate_Tick(object sender, EventArgs e)
        {
            if (!isPaused)
            {
                foreach (var planet in planets)
                {
                    planet.Angle += planet.Speed * 100 * speedMultiplier;
                }
                this.Invalidate();
            }
        }

        private void Form1_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0) zoom *= 1.1f;
            else zoom /= 1.1f;
            this.Invalidate();
        }

        private void btnPause_Click(object sender, EventArgs e) => isPaused = !isPaused;
        private void btnFaster_Click(object sender, EventArgs e) => speedMultiplier *= 1.5f;
        private void btnSlower_Click(object sender, EventArgs e) => speedMultiplier /= 1.5f;
    }

    public class Planet
    {
        public string Name { get; set; }
        public float OrbitRadius { get; set; }
        public float Speed { get; set; }
        public float Size { get; set; }
        public Color Color { get; set; }
        public float Angle { get; set; }

        public Planet(string name, float orbit, float speed, float size, Color color, float angle)
        {
            Name = name;
            OrbitRadius = orbit;
            Speed = speed;
            Size = size;
            Color = color;
            Angle = angle;
        }
    }
}
