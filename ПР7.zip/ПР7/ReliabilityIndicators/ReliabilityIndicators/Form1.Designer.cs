﻿namespace ReliabilityIndicators
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lblErrors = new System.Windows.Forms.Label();
            this.txtErrors = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.rtbResults = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(20, 15);
            this.lblTitle.Size = new System.Drawing.Size(300, 16);
            this.lblTitle.Text = "Расчет вероятности ошибки (Вариант 4)";
            // 
            // lblTotal
            // 
            this.lblTotal.Location = new System.Drawing.Point(20, 50);
            this.lblTotal.Size = new System.Drawing.Size(180, 20);
            this.lblTotal.Text = "Общее количество записей (N):";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(210, 47);
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.Text = "10000";
            // 
            // lblErrors
            // 
            this.lblErrors.Location = new System.Drawing.Point(20, 80);
            this.lblErrors.Size = new System.Drawing.Size(180, 20);
            this.lblErrors.Text = "Количество ошибок (n):";
            // 
            // txtErrors
            // 
            this.txtErrors.Location = new System.Drawing.Point(210, 77);
            this.txtErrors.Size = new System.Drawing.Size(100, 20);
            this.txtErrors.Text = "40";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(23, 115);
            this.btnCalculate.Size = new System.Drawing.Size(287, 30);
            this.btnCalculate.Text = "Рассчитать Рош";
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // rtbResults
            // 
            this.rtbResults.Location = new System.Drawing.Point(23, 160);
            this.rtbResults.ReadOnly = true;
            this.rtbResults.Size = new System.Drawing.Size(287, 120);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(344, 301);
            this.Controls.Add(this.rtbResults);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtErrors);
            this.Controls.Add(this.lblErrors);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblTitle);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Достоверность - Вариант 4";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label lblErrors;
        private System.Windows.Forms.TextBox txtErrors;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.RichTextBox rtbResults;
    }
}