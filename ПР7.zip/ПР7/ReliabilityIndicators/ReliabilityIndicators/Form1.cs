﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ReliabilityIndicators
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double N = double.Parse(txtTotal.Text);
                double n = double.Parse(txtErrors.Text);

                double p_err = n / N;

                rtbResults.Clear();
                rtbResults.AppendText("РЕЗУЛЬТАТЫ РАСЧЕТА:\n\n");
                rtbResults.AppendText($"Вероятность ошибки (Рош) для одной записи:\n");
                rtbResults.AppendText($"Рош = n / N = {n} / {N}\n");
                rtbResults.AppendText($"Рош = {p_err:F4}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }
    }
}
