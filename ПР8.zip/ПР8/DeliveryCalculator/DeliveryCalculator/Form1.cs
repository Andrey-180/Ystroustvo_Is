﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Web.Script.Serialization;

namespace DeliveryCalculator
{
    public partial class Form1 : Form
    {
        private List<HistoryItem> historyItems = new List<HistoryItem>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbTransport.SelectedIndex = 0;
        }

        private async void btnCalculate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFrom.Text) || string.IsNullOrWhiteSpace(txtTo.Text))
            {
                MessageBox.Show("Заполните оба пункта!");
                return;
            }

            try
            {
                lblStatus.Text = "Запрос к серверу...";
                var coordA = await GetCoordinates(txtFrom.Text);
                var coordB = await GetCoordinates(txtTo.Text);
                var route = await GetRouteData(coordA, coordB);

                double distanceKm = route.distance / 1000.0;
                double[] rates = { 200, 300, 10000, 5000, 50000 };
                double[] speeds = { 180, 65, 2484, 6, 2750 };

                double cost = distanceKm * rates[cmbTransport.SelectedIndex];
                double travelHours = distanceKm / speeds[cmbTransport.SelectedIndex];

                DateTime arrivalTime = DateTime.Now.AddHours(travelHours);
                string[] vehicles = { "Дрон Герань", "Танк Т-72Б3", "Пакет Град", "Рота ССО", "Миг-35" };
                string formattedArrival = arrivalTime.ToString("dd.MM.yyyy HH:mm");

                rtbResult.Clear();
                rtbResult.SelectionFont = new System.Drawing.Font(rtbResult.Font, System.Drawing.FontStyle.Bold);
                rtbResult.AppendText("ОТЧЁТ ПО МАРШРУТУ\n");
                rtbResult.AppendText("--------------------------------------------------\n");
                rtbResult.AppendText($"Объект: {vehicles[cmbTransport.SelectedIndex]}\n");
                rtbResult.AppendText($"Дистанция: {distanceKm:F2} км\n");
                rtbResult.AppendText($"Скорость: {speeds[cmbTransport.SelectedIndex]} км/ч\n");
                rtbResult.AppendText($"Прибытие в цель: {formattedArrival}\n");
                rtbResult.AppendText($"Сумма затрат: {cost:N0} руб.");

                lblStatus.Text = "Расчёт успешно выполнен";

                historyItems.Add(new HistoryItem
                {
                    Arrival = formattedArrival,
                    From = txtFrom.Text,
                    To = txtTo.Text,
                    Unit = vehicles[cmbTransport.SelectedIndex],
                    Price = cost.ToString("N0")
                });

                UpdateHistory();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
                lblStatus.Text = "";
            }
        }

        private void UpdateHistory()
        {
            dgvHistory.DataSource = null;
            dgvHistory.DataSource = historyItems;

            dgvHistory.Columns["Arrival"].HeaderText = "Прибытие";
            dgvHistory.Columns["From"].HeaderText = "Пункт А";
            dgvHistory.Columns["To"].HeaderText = "Пункт Б";
            dgvHistory.Columns["Unit"].HeaderText = "Объект";
            dgvHistory.Columns["Price"].HeaderText = "Сумма (руб)";

            dgvHistory.Columns["Arrival"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgvHistory.Columns["Price"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgvHistory.Columns["From"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvHistory.Columns["To"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvHistory.Columns["Unit"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private async System.Threading.Tasks.Task<string> GetCoordinates(string address)
        {
            if (address.Contains(",")) return address.Replace(" ", "");
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("User-Agent", "App");
                string url = $"https://nominatim.openstreetmap.org/search?q={Uri.EscapeDataString(address)}&format=json&limit=1";
                string json = await client.GetStringAsync(url);
                var ser = new JavaScriptSerializer();
                var res = ser.Deserialize<List<dynamic>>(json);
                if (res.Count == 0) throw new Exception("Адрес не найден");
                return $"{res[0]["lat"]},{res[0]["lon"]}";
            }
        }

        private async System.Threading.Tasks.Task<RouteInfo> GetRouteData(string start, string end)
        {
            using (HttpClient client = new HttpClient())
            {
                string[] s = start.Split(',');
                string[] e = end.Split(',');
                string url = $"http://router.project-osrm.org/route/v1/driving/{s[1]},{s[0]};{e[1]},{e[0]}?overview=false";
                string json = await client.GetStringAsync(url);
                var ser = new JavaScriptSerializer();
                var data = ser.Deserialize<dynamic>(json);
                return new RouteInfo
                {
                    distance = Convert.ToDouble(data["routes"][0]["distance"]),
                    duration = Convert.ToDouble(data["routes"][0]["duration"])
                };
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFrom.Clear(); txtTo.Clear(); rtbResult.Clear(); lblStatus.Text = "";
        }
    }

    public class RouteInfo { public double distance; public double duration; }
    public class HistoryItem { public string Arrival { get; set; } public string From { get; set; } public string To { get; set; } public string Unit { get; set; } public string Price { get; set; } }
}