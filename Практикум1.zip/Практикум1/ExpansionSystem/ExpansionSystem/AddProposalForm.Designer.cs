﻿namespace ExpansionSystem
{
    partial class AddProposalForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtDep = new System.Windows.Forms.TextBox();
            this.txtProp = new System.Windows.Forms.TextBox();
            this.cmbPriority = new System.Windows.Forms.ComboBox();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.txtRationale = new System.Windows.Forms.RichTextBox();
            this.dtpDeadline = new System.Windows.Forms.DateTimePicker();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblDep = new System.Windows.Forms.Label();
            this.lblProp = new System.Windows.Forms.Label();
            this.lblPrior = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.lblRationale = new System.Windows.Forms.Label();
            this.lblDeadline = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtDep
            // 
            this.txtDep.Location = new System.Drawing.Point(150, 20);
            this.txtDep.Name = "txtDep";
            this.txtDep.Size = new System.Drawing.Size(220, 20);
            // 
            // txtProp
            // 
            this.txtProp.Location = new System.Drawing.Point(150, 50);
            this.txtProp.Name = "txtProp";
            this.txtProp.Size = new System.Drawing.Size(220, 20);
            // 
            // cmbPriority
            // 
            this.cmbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPriority.Items.AddRange(new object[] { "Высокий", "Средний", "Низкий" });
            this.cmbPriority.Location = new System.Drawing.Point(150, 80);
            this.cmbPriority.Name = "cmbPriority";
            this.cmbPriority.Size = new System.Drawing.Size(121, 21);
            // 
            // txtCost
            // 
            this.txtCost.Location = new System.Drawing.Point(150, 110);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(100, 20);
            // 
            // txtRationale
            // 
            this.txtRationale.Location = new System.Drawing.Point(150, 140);
            this.txtRationale.Name = "txtRationale";
            this.txtRationale.Size = new System.Drawing.Size(220, 60);
            this.txtRationale.Text = "";
            // 
            // dtpDeadline
            // 
            this.dtpDeadline.Location = new System.Drawing.Point(150, 210);
            this.dtpDeadline.Name = "dtpDeadline";
            this.dtpDeadline.Size = new System.Drawing.Size(200, 20);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(82, 260);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.Text = "Сохранить";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(202, 260);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.Text = "Отмена";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblDep
            // 
            this.lblDep.AutoSize = true;
            this.lblDep.Location = new System.Drawing.Point(20, 23);
            this.lblDep.Text = "Подразделение:";
            // 
            // lblProp
            // 
            this.lblProp.AutoSize = true;
            this.lblProp.Location = new System.Drawing.Point(20, 53);
            this.lblProp.Text = "Предложение:";
            // 
            // lblPrior
            // 
            this.lblPrior.AutoSize = true;
            this.lblPrior.Location = new System.Drawing.Point(20, 83);
            this.lblPrior.Text = "Приоритет:";
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Location = new System.Drawing.Point(20, 113);
            this.lblCost.Text = "Стоимость:";
            // 
            // lblRationale
            // 
            this.lblRationale.AutoSize = true;
            this.lblRationale.Location = new System.Drawing.Point(20, 143);
            this.lblRationale.Text = "Обоснование:";
            // 
            // lblDeadline
            // 
            this.lblDeadline.AutoSize = true;
            this.lblDeadline.Location = new System.Drawing.Point(20, 213);
            this.lblDeadline.Text = "Срок реализации:";
            // 
            // AddProposalForm
            // 
            this.ClientSize = new System.Drawing.Size(400, 310);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblDeadline, this.lblRationale, this.lblCost, this.lblPrior,
                this.lblProp, this.lblDep, this.btnCancel, this.btnSave,
                this.dtpDeadline, this.txtRationale, this.txtCost,
                this.cmbPriority, this.txtProp, this.txtDep
            });
            this.Name = "AddProposalForm";
            this.Text = "Добавление нового предложения";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtDep;
        private System.Windows.Forms.TextBox txtProp;
        private System.Windows.Forms.ComboBox cmbPriority;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.RichTextBox txtRationale;
        private System.Windows.Forms.DateTimePicker dtpDeadline;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblDep;
        private System.Windows.Forms.Label lblProp;
        private System.Windows.Forms.Label lblPrior;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label lblRationale;
        private System.Windows.Forms.Label lblDeadline;
    }
}