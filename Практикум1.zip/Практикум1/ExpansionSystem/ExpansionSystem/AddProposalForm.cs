﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExpansionSystem
{
    public partial class AddProposalForm : Form
    {
        string cs;
        public AddProposalForm(string conn)
        {
            InitializeComponent();
            cs = conn;
            cmbPriority.SelectedIndex = 1; // "Средний" по умолчанию
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(cs))
                {
                    string sql = "INSERT INTO proposal (Department, ProposalText, Priority, Cost, Rationale, Deadline) VALUES (@d, @p, @pr, @c, @r, @dl)";
                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@d", txtDep.Text);
                    cmd.Parameters.AddWithValue("@p", txtProp.Text);
                    cmd.Parameters.AddWithValue("@pr", cmbPriority.Text);
                    cmd.Parameters.AddWithValue("@c", decimal.Parse(txtCost.Text));
                    cmd.Parameters.AddWithValue("@r", txtRationale.Text);
                    cmd.Parameters.AddWithValue("@dl", dtpDeadline.Value);

                    cn.Open();
                    cmd.ExecuteNonQuery();
                    this.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка: " + ex.Message); }
        }

        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}
