﻿namespace ExpansionSystem
{
    partial class DetailsForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && (components != null)) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.rtbDetails = new System.Windows.Forms.RichTextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.rtbDetails.Location = new System.Drawing.Point(12, 12); this.rtbDetails.Size = new System.Drawing.Size(360, 240);
            this.btnClose.Location = new System.Drawing.Point(150, 260); this.btnClose.Text = "Закрыть"; this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.ClientSize = new System.Drawing.Size(384, 305);
            this.Controls.Add(this.rtbDetails);
            this.Controls.Add(this.btnClose);
            this.Text = "Детали";
            this.ResumeLayout(false);
        }
        private System.Windows.Forms.RichTextBox rtbDetails;
        private System.Windows.Forms.Button btnClose;
    }
}