﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExpansionSystem
{
    public partial class DetailsForm : Form
    {
        public DetailsForm(int id, string cs)
        {
            InitializeComponent();
            try
            {
                using (SqlConnection cn = new SqlConnection(cs))
                {
                    SqlCommand cmd = new SqlCommand("SELECT * FROM proposal WHERE Id = @id", cn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        rtbDetails.Text = $"ПОДРОБНАЯ ИНФОРМАЦИЯ\n\nID: {dr["Id"]}\n" +
                            $"Отдел: {dr["Department"]}\nПредложение: {dr["ProposalText"]}\n" +
                            $"Приоритет: {dr["Priority"]}\nСтоимость: {dr["Cost"]} руб.\n" +
                            $"Срок: {Convert.ToDateTime(dr["Deadline"]).ToShortDateString()}\n\n" +
                            $"ОБОСНОВАНИЕ:\n{dr["Rationale"]}";
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка: " + ex.Message); }
        }
        private void btnClose_Click(object sender, EventArgs e) => this.Close();
    }
}
