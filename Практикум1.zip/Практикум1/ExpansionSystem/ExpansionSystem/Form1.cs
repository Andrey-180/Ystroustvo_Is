﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExpansionSystem
{
    public partial class Form1 : Form
    {
        
        public string connectionString = @"Data Source=localhost;Initial Catalog=IS_Expansion;Integrated Security=True;Encrypt=False";

        public Form1()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(connectionString))
                {
                    // Выбираем колонки для главной таблицы
                    string query = "SELECT Id, Department as 'Подразделение', ProposalText as 'Предложение', Priority as 'Приоритет', Cost as 'Стоимость' FROM proposal";
                    SqlDataAdapter da = new SqlDataAdapter(query, cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvProposals.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddProposalForm f = new AddProposalForm(connectionString);
            if (f.ShowDialog() == DialogResult.OK)
            {
                LoadData(); 
            }
        }

        private void btnDetails_Click(object sender, EventArgs e)
        {
            if (dgvProposals.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgvProposals.SelectedRows[0].Cells["Id"].Value);
                new DetailsForm(id, connectionString).ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите строку в таблице!");
            }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            new ReportForm(connectionString).ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
