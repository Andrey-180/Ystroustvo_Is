﻿namespace ExpansionSystem
{
    partial class ReportForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && (components != null)) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.rtbReport = new System.Windows.Forms.RichTextBox();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.rtbReport.Location = new System.Drawing.Point(12, 12); this.rtbReport.Size = new System.Drawing.Size(460, 330);
            this.btnPrint.Location = new System.Drawing.Point(100, 355); this.btnPrint.Text = "Печать"; this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            this.btnClose.Location = new System.Drawing.Point(260, 355); this.btnClose.Text = "Закрыть"; this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.ClientSize = new System.Drawing.Size(484, 400);
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.rtbReport, this.btnPrint, this.btnClose });
            this.Text = "Отчет";
            this.ResumeLayout(false);
        }
        private System.Windows.Forms.RichTextBox rtbReport;
        private System.Windows.Forms.Button btnPrint, btnClose;
    }
}