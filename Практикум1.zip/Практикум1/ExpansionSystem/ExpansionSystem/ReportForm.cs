﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExpansionSystem
{
    public partial class ReportForm : Form
    {
        public ReportForm(string cs)
        {
            InitializeComponent();
            try
            {
                using (SqlConnection cn = new SqlConnection(cs))
                {
                    SqlCommand cmd = new SqlCommand("SELECT * FROM proposal", cn);
                    cn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    string r = "ОТЧЕТ ПО ПРЕДЛОЖЕНИЯМ\n====================\n\n";
                    while (dr.Read())
                    {
                        r += $"[{dr["Id"]}] {dr["Department"]}: {dr["Cost"]} руб.\n";
                    }
                    rtbReport.Text = r;
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка: " + ex.Message); }
        }
        private void btnPrint_Click(object sender, EventArgs e) => MessageBox.Show("Документ отправлен на печать.");
        private void btnClose_Click(object sender, EventArgs e) => this.Close();
    }
}
