﻿namespace WordGameApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.flpScrambled = new System.Windows.Forms.FlowLayoutPanel();
            this.flpResult = new System.Windows.Forms.FlowLayoutPanel();
            this.btnCheck = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblPrompt1 = new System.Windows.Forms.Label();
            this.lblPrompt2 = new System.Windows.Forms.Label();
            this.lblPrompt3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            this.lblTitle.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.Navy;
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(560, 45);
            this.lblTitle.Text = "ПОЛЕ ЧУДЕС";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtInput.Location = new System.Drawing.Point(220, 65);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(260, 20);
            this.btnStart.Location = new System.Drawing.Point(490, 63);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.Text = "Начать";
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            this.flpScrambled.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flpScrambled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpScrambled.Location = new System.Drawing.Point(20, 115);
            this.flpScrambled.Name = "flpScrambled";
            this.flpScrambled.Size = new System.Drawing.Size(545, 60);
            this.flpResult.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flpResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpResult.Location = new System.Drawing.Point(20, 210);
            this.flpResult.Name = "flpResult";
            this.flpResult.Size = new System.Drawing.Size(545, 60);
            this.btnCheck.BackColor = System.Drawing.Color.LightGreen;
            this.btnCheck.Location = new System.Drawing.Point(150, 285);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(120, 35);
            this.btnCheck.Text = "Проверить";
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            this.btnReset.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnReset.Location = new System.Drawing.Point(320, 285);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(120, 35);
            this.btnReset.Text = "Новая игра";
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            this.lblStatus.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.lblStatus.Location = new System.Drawing.Point(20, 330);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(545, 30);
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPrompt1.Location = new System.Drawing.Point(20, 68);
            this.lblPrompt1.Name = "lblPrompt1";
            this.lblPrompt1.Size = new System.Drawing.Size(194, 13);
            this.lblPrompt1.Text = "Введите слово для угадывания:";
            this.lblPrompt2.Location = new System.Drawing.Point(20, 95);
            this.lblPrompt2.Name = "lblPrompt2";
            this.lblPrompt2.Size = new System.Drawing.Size(120, 13);
            this.lblPrompt2.Text = "Перепутанные буквы:";
            this.lblPrompt3.Location = new System.Drawing.Point(20, 190);
            this.lblPrompt3.Name = "lblPrompt3";
            this.lblPrompt3.Size = new System.Drawing.Size(350, 13);
            this.lblPrompt3.Text = "Соберите слово (нажимайте кнопки в правильном порядке):";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 381);
            this.Controls.Add(this.lblPrompt3);
            this.Controls.Add(this.lblPrompt2);
            this.Controls.Add(this.lblPrompt1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.flpResult);
            this.Controls.Add(this.flpScrambled);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.lblTitle);
            this.Name = "Form1";
            this.Text = "Поле Чудес";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.FlowLayoutPanel flpScrambled;
        private System.Windows.Forms.FlowLayoutPanel flpResult;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblPrompt1;
        private System.Windows.Forms.Label lblPrompt2;
        private System.Windows.Forms.Label lblPrompt3;
    }
}