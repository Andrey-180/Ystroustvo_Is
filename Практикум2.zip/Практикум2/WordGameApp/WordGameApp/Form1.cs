﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordGameApp
{
    public partial class Form1 : Form
    {
        private string targetWord = "";
        private Random random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            targetWord = txtInput.Text.Trim().ToUpper();
            if (string.IsNullOrEmpty(targetWord)) return;

            txtInput.Visible = false;
            lblPrompt1.Visible = false;
            btnStart.Enabled = false;
            lblStatus.Text = "";

            char[] letters = targetWord.ToCharArray();
            letters = letters.OrderBy(x => random.Next()).ToArray();

            flpScrambled.Controls.Clear();
            flpResult.Controls.Clear();

            foreach (char c in letters)
            {
                Button btn = CreateLetterButton(c.ToString());
                btn.Click += ScrambledLetter_Click;
                flpScrambled.Controls.Add(btn);
            }
        }

        private Button CreateLetterButton(string text)
        {
            return new Button
            {
                Text = text,
                Size = new Size(45, 45),
                Font = new Font("Arial", 12, FontStyle.Bold),
                BackColor = Color.Yellow,
                FlatStyle = FlatStyle.Flat
            };
        }

        private void ScrambledLetter_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            flpScrambled.Controls.Remove(btn);
            btn.Click -= ScrambledLetter_Click;
            btn.Click += ResultLetter_Click;
            btn.BackColor = Color.LightGreen;
            flpResult.Controls.Add(btn);
        }

        private void ResultLetter_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            flpResult.Controls.Remove(btn);
            btn.Click -= ResultLetter_Click;
            btn.Click += ScrambledLetter_Click;
            btn.BackColor = Color.Yellow;
            flpScrambled.Controls.Add(btn);
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string assembledWord = "";
            foreach (Control ctrl in flpResult.Controls) assembledWord += ctrl.Text;

            if (assembledWord == targetWord)
            {
                lblStatus.ForeColor = Color.Green;
                lblStatus.Text = "Поздравляем! Вы правильно собрали слово!";
            }
            else
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Неверно! Правильное слово: " + targetWord;
                txtInput.Visible = true;
                lblPrompt1.Visible = true;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtInput.Visible = true;
            lblPrompt1.Visible = true;
            btnStart.Enabled = true;
            txtInput.Clear();
            flpScrambled.Controls.Clear();
            flpResult.Controls.Clear();
            lblStatus.Text = "";
            targetWord = "";
            txtInput.Focus();
        }
    }
}
